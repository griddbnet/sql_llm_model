from flask import Flask, request, send_from_directory
from flask_cors import CORS, cross_origin

app = Flask(__name__,
            static_url_path='', 
            static_folder='web/static',
            template_folder='web/templates')

cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

@app.route('/')
def root():
    return app.send_static_file('index.html')

@app.route('/query', methods = ['POST'])
@cross_origin()
def query():
   question = request.json['question']
   context = request.json['context']
   print(question + ", " + context)
   query = "SELECT timestamp FROM testing;"
   return query


if __name__ == '__main__':
   app.run(host="0.0.0.0")